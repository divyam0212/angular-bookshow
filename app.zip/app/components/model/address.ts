import { City } from './city';
import { State } from './state';

export class Address{
    constructor(
    public city?:City,
    public state?:State){

    }
}