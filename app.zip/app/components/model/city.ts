export class City{
    constructor(
        public cityId?:any,
        public cityName?:any
    ){

    }
}