import { Language } from './language';

export class Venue{
    constructor(public bookDate?:any,public language?:Language){
        
    }
}