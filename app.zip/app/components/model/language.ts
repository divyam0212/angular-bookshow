export class Language{
    constructor(
        public languageId?:any,
        public languageName?:any
    ){

    }
}