export class State{
    constructor(
        public stateId?:any,
        public stateName?:any
    ){

    }
}