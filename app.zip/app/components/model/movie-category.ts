import { Movie } from './movie';
import { Category } from './category';
import { Language } from './language';

export class MovieCategory{
    constructor(
        public movieCategoryId?:any,
        public movie?:Movie,
        public category?:string,
        public language?:string
    ){

    }
}