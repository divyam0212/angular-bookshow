import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Movie } from '../model/movie';
import { Category } from '../model/category';
import { Language } from '../model/language';
import { MovieCategory } from '../model/movie-category';
import { AppComponent } from '../../app.component';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  private cityId:any;
  private movieList:any;
  private movie:Movie=new Movie("","","");
  private category:string;
  private language:string;

  private movieCategory:MovieCategory=new MovieCategory("",this.movie,"","");

  constructor(private app: AppComponent,private _services:BookOurShowService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.cityId=this.route.snapshot.paramMap.get("cityId");
    // alert("WELCOME TO MOVIE COMPONENT CITY ID: "+this.cityId);
    //this.app.loginFlag=true;
    this._services.fetchMovie().subscribe(
      (res)=>{
        console.log(res+" Success ");
        this.movieList=res;
        
        // alert("MOVIE FETCH SUCCESSFULL");
        // alert("MOVIE:\n"+JSON.stringify(this.movieList));

        

        // this.router.navigate(['/success']);
      },(error:HttpErrorResponse)=>{
        console.log(error+" Failure ");
        if(error instanceof Error){
            console.log("Client side error "+error);
        }
        else
        {
            console.log("Server side error "+error);
        }
      }
    );
  }
  onBook(movieId:any){
    alert("CITY ID & MOVIE ID IS: "+this.cityId+movieId);
    this.router.navigate(['/language',this.cityId,movieId]);
    
  }

}
