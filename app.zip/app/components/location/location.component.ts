import { Component, OnInit } from '@angular/core';
import { BookOurShowService } from '../services/bookshow.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Address } from '../model/address';
import { City } from '../model/city';
import { State } from '../model/state';
import { AppComponent } from '../../app.component';

@Component({
  selector: 'location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  private addressList:any;
  private city:City=new City("","");
  private state:State=new State("","");
  user:any;
  private address:Address=new Address(this.city,this.state);
  constructor(private app: AppComponent,private _services:BookOurShowService,private router:Router) { }

  ngOnInit() {
      //this.app.loginFlag=true;
      this._services.fetchLocation().subscribe(
        (res)=>{
          console.log(res+" Success ");
          this.addressList=res;
          //alert("LOCATION FETCH SUCCESSFULL");
          //alert("LOCATION:\n"+JSON.stringify(this.addressList));

          // this.router.navigate(['/success']);
        },(error:HttpErrorResponse)=>{
          console.log(error+" Failure ");
          if(error instanceof Error){
              console.log("Client side error "+error);
          }
          else
          {
              console.log("Server side error "+error);
          }
        }
      );
  }
  
  check(){
    alert(JSON.stringify(this.address.city));
    alert("CITY ID IN /location is: "+this.address.city.cityId);
    this.router.navigate(['/movie',this.address.city.cityId]);
  }
}
