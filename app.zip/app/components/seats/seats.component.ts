import { Component, OnInit } from '@angular/core';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';

@Component({
  selector: 'app-seats',
  templateUrl: './seats.component.html',
  styleUrls: ['./seats.component.css']
})
export class SeatsComponent implements OnInit {
  private allSeats:any;
  private bookedSeats:any;
  private venueScheduleId:any;
  private bookDate:any;
   newBookedSeats:Array<string> =new Array();
   bookingDetails:any;
  private flag:boolean;
  userId:any;
  finalBooking:any;
  seatColor:any;
  changecolor:boolean;
  user:any;
  value:boolean;
  constructor(private service:BookOurShowService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.venueScheduleId=this.route.snapshot.paramMap.get("venueScheduleId");
    this.bookDate=this.route.snapshot.paramMap.get("bookDate");
    this.service.fetchallSeats().subscribe(
      (res)=>{
        console.log(res+" Success ");
        this.allSeats=res;
        },
        (error:HttpErrorResponse)=>{
          console.log(error+" Failure ");
          if(error instanceof Error){
              console.log("Client side error "+error);
          }
          else
          {
              console.log("Server side error "+error);
          }
        }
    );
    this.service.fetchBookedSeats(this.venueScheduleId,this.bookDate).subscribe(
      (res)=>
      {
        console.log(res+" Success ");
        this.bookedSeats=res;
      },
      (error:HttpErrorResponse)=>{
        console.log(error+" Failure ");
        if(error instanceof Error){
            console.log("Client side error "+error);
        }
        else
        {
            console.log("Server side error "+error);
        }
      }
    );

  }
  verify():any{
    this.value=false;
    if(this.newBookedSeats.length==0){
      this.value=true;
    }
    else{
      this.value=false;
    }
    return this.value;
  }
  isPresent(seat){
      if(this.bookedSeats.includes(seat))
      {
        return true;
      }
     return false;
  }
  /* addSeats(event:any,seat:string){
    alert(this.newBookedSeats);
      if(event.target.checked){
        alert(seat);
          this.newBookedSeats.push(seat);
      }

        if(!event.target.checked){
          this.newBookedSeats.forEach((element,index) => {
           alert("the element is "+element+" and seat is "+seat);
            if(element===seat){
              this.newBookedSeats.splice(index,1);
            }
          });

        }
        alert("the final list is "+this.newBookedSeats);
  } */
  check(seat:any){

    alert("seat---->"+seat);
    if(this.newBookedSeats.includes(seat)){
      var index=this.newBookedSeats.indexOf(seat);
      this.newBookedSeats.splice(index,1);
      var result = document.getElementById(seat);
      result.style.color="green";
    }
    else{
      this.newBookedSeats.push(seat);
      var result = document.getElementById(seat);
      result.style.color="yellow";
    }
    alert("final list----->"+this.newBookedSeats);
  }
  bookNow(){
    this.user=JSON.parse(localStorage.getItem("user"));
    alert("USER------->"+this.user.userId);
    var booking={
      "user": {
        "userId": this.user.userId
      },
      "venueSchedule": {
        "venueScheduleId": this.venueScheduleId
      },
      "bookDate": this.bookDate
    };

    this.service.registerBooking(booking).subscribe(
      (res)=>{
        console.log(res+" Success ");
        this.bookingDetails=res;
        alert("BOOKING SUCCESSFULL"+this.bookingDetails.bookingId);
        this.service.updateReceipt(this.bookingDetails.bookingId,this.newBookedSeats).subscribe(
          (res)=>{
            console.log(res+" Success ");
            this.finalBooking=res;
            alert("BOOKING---->"+this.finalBooking);
            //alert("BOOKING:\n"+JSON.stringify(this.finalBooking));
           
            this.router.navigate(['/bill',this.finalBooking.bookingId],{queryParams:{seats:this.newBookedSeats}});
          },(error:HttpErrorResponse)=>{
            console.log(error+" Failure ");
            if(error instanceof Error){
                console.log("Client side error "+error);
            }
            else
            {
                console.log("Server side error "+error);
            }
          }
        );
      },(error:HttpErrorResponse)=>{
        console.log(error+" Failure ");
        if(error instanceof Error){
            console.log("Client side error "+error);
        }
        else
        {
            console.log("Server side error "+error);
        }
      }
    );

  }
  i=1;
  bFlag:boolean;
  breakLine():boolean{
    if(this.i!=4)
    {
        this.i++;
        this.bFlag=false;
    }
    else{
      this.i=1;
      this.bFlag=true;
    }
    return this.bFlag;
  }
}
