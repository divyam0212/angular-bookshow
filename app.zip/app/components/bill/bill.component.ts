import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {

  seatDetails:any;
  booking:any;
  bookingId:any;
  constructor(private router:Router,private route:ActivatedRoute,private service:BookOurShowService) { }

  logout():any{
   this.router.navigate(['/logout']) ;
  }

  ngOnInit() {
    alert("WELCOME TO BILL COMPONENT");
    this.seatDetails=this.route.snapshot.queryParams['seats'];
    this.bookingId=this.route.snapshot.paramMap.get('bookingId');

    this.service.fetchBookingDetails(this.bookingId).subscribe(
      (res)=>{
        console.log(res+" Success ");
        this.booking=res;
      },(error:HttpErrorResponse)=>{
        console.log(error+" Failure ");
        if(error instanceof Error){
            console.log("Client side error "+error);
        }
        else
        {
            console.log("Server side error "+error);
        }
      }
    );

    console.log("SeatDetails---------->"+this.seatDetails);
    console.log("BOOKING----------->"+this.booking);
  }
  
}
