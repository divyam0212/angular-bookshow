import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { LoginComponent } from '../login/login.component';
import { BookOurShowService } from '../services/bookshow.service';
import { Login } from '../model/login';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service:BookOurShowService,private router:Router) { }
  login:Login = new Login();
  //login:Login= new Login();
  message:string;
  onSubmit(){

    this.service.validateUser(this.login).subscribe(
      (res)=>{
        if(res["email"]!=null && res["password"]!=null)
        {
          alert("USER ALREADY EXISTS IN DB");
          this.login.setUserName("");
          this.login.setEmail("");
          this.login.setPassword("");
        }
        else{
          this.service.registerUser(this.login).subscribe(
            (res)=>{
              if(res["email"]!=null && res["password"]!=null)
              {
                alert ("LOGIN TO CONTINUE");
                this.router.navigate(["login"]);
              }
            },
            (error:HttpErrorResponse)=>{
              if(error instanceof Error)
             {
               console.log("Client side error "+error.statusText);
             }
             else{
               console.log("Server side error "+error.statusText);
             }
           }
      
          );
        }
      },
      (error:HttpErrorResponse)=>{
         if(error instanceof Error)
        {
          console.log("Client side error "+error.statusText);
        }
        else{
          console.log("Server side error "+error.statusText);
        }
      }
      
    );
  }
  ngOnInit() {
  }

}
