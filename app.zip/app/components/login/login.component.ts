import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../../app.component';
import { BookOurShowService } from '../services/bookshow.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private login:boolean=true;
  returnUrl:any;
  constructor(private app: AppComponent,private route:ActivatedRoute,private _loginService:BookOurShowService,private router:Router) { }

  ngOnInit() {
    this.returnUrl=this.route.snapshot.queryParams['returnUrl'];
  }

  loginForm=new FormGroup(
  {
    email:new FormControl(''),
    password:new FormControl('')
  });

  signupForm=new FormGroup(
    {
      userName:new FormControl(''),
      email: new FormControl(''),
      password:new FormControl('')
    });

    onSignUpSubmit()
    {
     
      this._loginService.validateUser(this.signupForm.value).subscribe(
        (res)=>{
          this._loginService.registerUser(this.signupForm.value).subscribe(
            (res)=>{
              alert("REGISTERED SUCCESSFULLY !!!!");
              this._loginService.setUser(JSON.stringify(res));
              this.router.navigate(['/login']);
            },
            (error:HttpErrorResponse)=>
            {
    
            }
          );
          
        },
        (error:HttpErrorResponse)=>
        {
          console.log(error+" Failure ");
          if(error instanceof Error){
              console.log("Client side error "+error);
          }
          else
          {
              console.log("Server side error "+error);
          }
        }
      );
    }
    onLoginSubmit()
    {
      
      this._loginService.validateUser(this.loginForm.value).subscribe(
          (res)=>{
            if(res["email"]!=null&&res["password"]!=null)
            {
               localStorage.setItem("user",JSON.stringify(res));
              if(this.returnUrl==null){
                this.router.navigate(['/location']);
              }
              else{
                this.router.navigateByUrl(this.returnUrl);
              }
          }else
          {
            alert("Invalid credentials or unregistered user");
            
          }
          },
          (error:HttpErrorResponse)=>
          {
            console.log(error+" Failure ");
            if(error instanceof Error){
                console.log("Client side error "+error);
            }
            else
            {
                console.log("Server side error "+error);
            }
          }
      );
    }
  

  onLoginClick()
  {
    this.login=true;
  }
  
  onSignClick()
  {
    this.login=false;
  }

}
