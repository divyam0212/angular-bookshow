import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LocationComponent } from './components/location/location.component';
import { BookOurShowService } from './components/services/bookshow.service';
import { MovieComponent } from './components/movie/movie.component';
import { LanguageComponent } from './components/language/language.component';
import { DatePipe } from '@angular/common';
import { VenueComponent } from './components/venue/venue.component';
import { SeatsComponent } from './components/seats/seats.component';
import { BillComponent } from './components/bill/bill.component';
import { LogoutComponent } from './components/logout/logout.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AuthGuard } from './guards/auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    LocationComponent,
    MovieComponent,
    LanguageComponent,
    VenueComponent,
    SeatsComponent,
    BillComponent,
    LogoutComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [BookOurShowService,DatePipe,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
